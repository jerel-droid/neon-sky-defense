GLOBAL DEFENSE - Android project
A touch-controlled missile interception arcade game inspired by classic missile-defense games.

BUILD:
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

For command-line build with Gradle installed: gradle assembleDebug

Controls: tap anywhere in the playfield to launch an interceptor toward that point.
Landscape orientation is enforced. No network permission or external assets are required.
