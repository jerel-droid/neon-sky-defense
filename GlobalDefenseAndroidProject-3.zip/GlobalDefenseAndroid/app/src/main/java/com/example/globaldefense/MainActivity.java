package com.example.globaldefense;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.content.pm.ActivityInfo;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
 getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
 setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
 WebView w=new WebView(this); w.setBackgroundColor(0xff050b18); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setOverScrollMode(View.OVER_SCROLL_NEVER); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){ }
}